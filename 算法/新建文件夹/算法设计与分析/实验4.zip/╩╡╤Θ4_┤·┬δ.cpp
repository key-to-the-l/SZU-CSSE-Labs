#include <iostream>
#include <vector>
#include<chrono>
#include<math.h>

using namespace std;
using namespace std::chrono;
#define scale 1000000
const int data_scale = 1;
const int eggs_top = scale;
const int floor_top = scale;

//ʱ�临�Ӷ�ʱ�临�Ӷ���Ϊ O(kn^2)���ռ临�Ӷ�O(kn)
int Force_EggsAndFloor(int eggs, int floor) {
	vector<vector<int>> dp(eggs + 1, vector<int>(floor + 1));
	for (int i = 1; i <= eggs; ++i) {
		dp[i][1] = 1;
	}
	for (int i = 1; i <= floor; ++i) {
		dp[1][i] = i;
	}
	for (int i = 2; i <= eggs; ++i){
		for (int j = 2; j <= floor; ++j) {
			int minnum = INT_MAX;
			for (int x = 2; x <= j; ++x) {
				int temp = max(dp[i - 1][x - 1], dp[i][j - x]);
				minnum = min(minnum, temp);
			}
			dp[i][j] = 1 + minnum;
		}
	}
	return dp[eggs][floor];
}
//ʱ�临�Ӷ�O(knlogn)���ռ临�Ӷ�O(n)
int BinarySearch_EggsAndFloor(int eggs, int floor) {
	vector<vector<int>> dp(2, vector<int>(floor + 1));
	for (int i = 0; i <=1; i++) {
		dp[i][1] = 1;
	}
	for (int i = 1; i <= floor; i++) {
		dp[1][i] = i;
	}
	for (int i = 2; i <= eggs; ++i) {
		for (int j = 2; j <= floor; ++j) {
			int left = 1,
				right = j;
			while (left + 1 < right) {
				int mid = (left + right) / 2;
				int up = dp[0][mid - 1];
				int down = dp[1][j - mid];
				if (up < down) {
					left = mid;
				}
				else if (up > down) {
					right = mid;
				}
				else {
					left = right = mid;
				}
			}
			int leftVal = max(dp[0][left - 1], dp[1][j - left]);
			int rightVal = max(dp[0][right - 1], dp[1][j - right]);
			dp[0][j] = dp[1][j];
			dp[1][j] = 1 + min(leftVal, rightVal);
		}
	}
	return dp[1][floor];
}
void Check_Answers() {
	int times = 1;
	std::cout << "�������ݹ�ģΪ" << 4 << endl;
	for (int i = 1; i <= 5; ++i) {
		int eggs = rand() % 100 + 10,
			floor = rand() % 100 + 10;
		int ans1=Force_EggsAndFloor(eggs, floor);
		int ans2=BinarySearch_EggsAndFloor(eggs, floor);
		std::cout << "���ڵ�" << times++ << "������:" << endl
			<< "��ʱ��" << eggs << "��������" << floor << "��" << endl
			<< "���β��Դ�Ϊ" << ans1 << endl;
		if (ans1 == ans2) {
			std::cout << "����ȷ����֤���" << endl<<endl;
		}else {
			std::cout << "�𰸴�����Ҫ�޸�" << endl<<endl;
		}
	}
	std::cout << "��֤�ɹ���������ȷ" << endl;
	std::cout << "--------------------------------------------------------------------------" << endl;
	std::cout << "--------------------------------------------------------------------------" << endl << endl;
}
void EfficiencyComparation() {
	int times = 1;
	for (int i = 1; i <= data_scale; ++i) {
		auto begintime = system_clock::now();
		int eggs = rand()%eggs_top+eggs_top/10,
			floor = rand()%floor_top+floor_top/10;
		int ans = BinarySearch_EggsAndFloor(eggs, floor);
		duration<double> diff = system_clock::now() - begintime;
		std::cout << "��" << times++ << "�����ݼ���������:" << endl;
		std::cout << "����" << eggs << "��������" << floor << "��,"<<endl<<"��ʱ:" << diff.count() << "�룬"<<endl<<"���Ѱ�����ҵ��ż������С����, ����" << ans << "��" << endl << endl;
	}
}

int main() {
	//Check_Answers();
	EfficiencyComparation();
}
