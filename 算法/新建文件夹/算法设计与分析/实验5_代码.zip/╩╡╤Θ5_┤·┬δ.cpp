#include<iostream>
#include<vector>
#include<chrono>
#include<fstream>

using namespace std;
using namespace std::chrono;

class Force_Bridges {
protected:
    vector<pair<int, int>> bridges;
    vector<vector<int>> map;
    vector<bool> visited;
    vector<pair<int, int>> edges;
    int edgeNumber;
    int vertexNumber;
    int blocks;
    int count;
public:
    Force_Bridges(int edgeNumber, int vertexNumber) : edgeNumber(edgeNumber), vertexNumber(vertexNumber) {
        map.resize(vertexNumber);
    }
    void AddEdge(int head, int tail, bool init = false) {
        map[head].push_back(tail);
        map[tail].push_back(head);
        if (init) {
            edges.emplace_back(head, tail);
        }
    }
    void DeleteEdge(int head, int tail) {
        for (auto it = map[head].begin(); it != map[head].end(); it++) {
            if (*it == tail) {
                map[head].erase(it);
                break;
            }
        }
        for (auto it = map[tail].begin(); it != map[tail].end(); it++) {
            if (*it == head) {
                map[tail].erase(it);
                break;
            }
        }
    }
    void DFS(int& current) {
        if (visited[current])
            return;
        visited[current] = true;
        count++;
        for (auto next : map[current]) {
            DFS(next);
        }
    }
    int CountBlocks() {
        int component = 0;
        visited.assign(vertexNumber, false);
        for (int i = 0; i < vertexNumber; i++) {
            count = 0;
            DFS(i);
            if (count) {
                component++;
            }
        }
        return component;
    }
    void Force_findBridge() {
        blocks = CountBlocks();
        for (auto& edge : edges) {
            DeleteEdge(edge.first, edge.second);
            if (blocks < CountBlocks()) {
                bridges.emplace_back(edge.first, edge.second);
            }
            AddEdge(edge.first, edge.second);
        }
    }
    void printfBridge() {
        for (auto& bridge : bridges) {
            cout << bridge.first << '-' << bridge.second << endl;
        }
        if (bridges.empty()) {
            cout << "No answer" << endl;
        }
    }
};
class Disjoint :public Force_Bridges {
protected:
    vector<pair<int, int>>edgesTemp;
    vector<int> root;
public:
    Disjoint(int edgeNumber, int vertexNumber) : Force_Bridges(edgeNumber, vertexNumber) {
        root.resize(vertexNumber);
    }
    void AddEdge(int head, int tail, bool init = false) {
        if (init) {
            edges.emplace_back(head, tail);
        } else {
            edgesTemp.emplace_back(head, tail);
        }
    }
    int CountBlocks() {
        int component = 0;
        for (int i = 0; i < vertexNumber; i++) {
            root[i] = i;
        }
        for (auto& edge : edgesTemp) {
            merge(edge.first, edge.second);
        }
        for (int i = 0; i < vertexNumber; i++) {
            if (root[i] == i) {
                component++;
            }
        }
        return component;
    }
    int findRoot(int& vertex) {
        if (root[vertex] == vertex) {
            return vertex;
        }
        return root[vertex] = findRoot(root[vertex]);
    }
    void merge(int& u, int& v) {
        int uRoot = findRoot(u);
        int vRoot = findRoot(v);
        if (uRoot != vRoot) {
            root[vRoot] = uRoot;
        }
    }
    void DeleteEdge(pair<int, int>edge) {
        for (auto it = edgesTemp.begin(); it != edgesTemp.end(); it++) {
            if (*it == edge) {
                edgesTemp.erase(it);
                break;
            }
        }
    }

    void Disjoint_findBridge() {
        edgesTemp = edges;
        blocks = CountBlocks();
        for (auto& edge : edges) {
            DeleteEdge(edge);
            if (blocks < CountBlocks()) {
                bridges.emplace_back(edge.first, edge.second);
            }
            AddEdge(edge.first, edge.second);
        }
    }
};
class LCA :public Force_Bridges {
protected:
    vector<pair<int, int>> notTreeEdges;
    vector<bool> notLoopEdges;
    vector<int> depth;
    vector<int> father;
public:
    LCA(int edgeNumber, int vertexNumber) :Force_Bridges(edgeNumber, vertexNumber) {
        map.resize(vertexNumber);
        depth.resize(vertexNumber);
        notLoopEdges.assign(vertexNumber, false);
        visited.assign(vertexNumber, false);
        father.resize(vertexNumber);
        for (int i = 0; i < vertexNumber; i++) {
            father[i] = i;
        }
    }

    void BuildTree(int& current, int deep, int& currentFather) {
        depth[current] = deep;
        father[current] = currentFather;
        visited[current] = true;
        for (auto& son : map[current]) {
            if (!visited[son]) {
                notLoopEdges[son] = true;
                BuildTree(son, deep + 1, current);
            }
        }
    }

    void CreateTree() {
        for (int i = 0; i < vertexNumber; i++) {
            if (!visited[i]) {
                BuildTree(i, 0, i);
            }
        }
    }

    void FindNotTreeEdge() {
        for (auto& edge : edges) {
            if (father[edge.first] != edge.second && father[edge.second] != edge.first) {
                notTreeEdges.emplace_back(edge.first, edge.second);
            }
        }
    }

    void FindLoopEdge(pair<int, int>& edge) {
        int u = edge.first;
        int v = edge.second;
        while (true) {
            if (depth[u] > depth[v]) {
                notLoopEdges[u] = false;
                u = father[u];
            } else if (depth[u] < depth[v]) {
                notLoopEdges[v] = false;
                v = father[v];
            } else if (u != v) {
                notLoopEdges[u] = false;
                u = father[u];
                notLoopEdges[v] = false;
                v = father[v];
            } else {
                break;
            }
        }
    }

    void LCA_findBridge() {
        CreateTree();
        FindNotTreeEdge();
        for (auto& edge : notTreeEdges) {
            FindLoopEdge(edge);
        }
    }

    void printfBridge() {
        for (int i = 0; i < vertexNumber; i++) {
            if (notLoopEdges[i]) {
                cout << i << '-' << father[i] << endl;
            }
        }
    }
};
class LCA_CompressPath :public LCA {
public:
    LCA_CompressPath(int edgeNumber, int vertexNumber) :LCA(edgeNumber, vertexNumber) {
        ;
    }

    void CompressPath(int current, int ancestor) {
        while (father[current] != ancestor) {
            int next = father[current];
            father[current] = ancestor;
            depth[current] = depth[ancestor] + 1;
            current = next;
        }
    }
    void FindLoopEdge(pair<int, int>& edge) {
        int u = edge.first;
        int v = edge.second;
        while (true) {
            if (depth[u] > depth[v]) {
                notLoopEdges[u] = false;
                u = father[u];
            } else if (depth[u] < depth[v]) {
                notLoopEdges[v] = false;
                v = father[v];
            } else if (u != v) {
                notLoopEdges[u] = false;
                u = father[u];
                notLoopEdges[v] = false;
                v = father[v];
            } else {
                CompressPath(edge.first, father[u]);
                CompressPath(edge.second, father[u]);
                break;
            }
        }
    }
    void LCA_findBridge() {
        CreateTree();
        FindNotTreeEdge();
        for (auto& edge : notTreeEdges) {
            FindLoopEdge(edge);
        }
    }
};

int main() {
    fstream file("D:/���ε���ҵ/�㷨��������/ʵ����/TestCorrectData.txt");
    if (!file.is_open()) {
        cout << "File Open Error!" << endl;
        return 0;
    }
    int edgeNumber;
    int vertexNumber;
    int head, tail;
    file >> vertexNumber >> edgeNumber;
    Force_Bridges test1(edgeNumber, vertexNumber);
    Disjoint test2(edgeNumber, vertexNumber);
    LCA test3(edgeNumber, vertexNumber);
    LCA_CompressPath test4(edgeNumber, vertexNumber);
    while (!file.eof()) {
        file >> head >> tail;
        test1.AddEdge(head, tail, true);
        test2.AddEdge(head, tail, true);
        test3.AddEdge(head, tail, true);
        test4.AddEdge(head, tail, true);
    }

    auto beginTime = system_clock::now();
    test1.Force_findBridge();
    duration<double> diff = system_clock::now() - beginTime;
    cout << "��ʱ" << diff.count() << endl;
    test1.printfBridge();
    cout << endl;

    beginTime = system_clock::now();
    test2.Disjoint_findBridge();
    diff = system_clock::now() - beginTime;
    cout << "��ʱ" << diff.count() << endl;
    test2.printfBridge();
    cout << endl;

    beginTime = system_clock::now();
    test3.LCA_findBridge();
    diff = system_clock::now() - beginTime;
    cout << "��ʱ" << diff.count() << endl;
    test3.printfBridge();
    cout << endl;

    beginTime = system_clock::now();
    test4.LCA_findBridge();
    diff = system_clock::now() - beginTime;
    cout << "��ʱ" << diff.count() << endl;
    test4.printfBridge();
    cout << endl;
}