#include <iostream>
#include <algorithm>
#include <cstring>
#include <random>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <fstream>

using namespace std;
const int MAXN = 500;

int graph[MAXN][MAXN]; // �ڽӾ����ʾͼ
int edge[8000][2];     // �߼�
int color[MAXN];       // �ڵ����ɫ״̬

int ans = 0;

const int pointNum = 450; // �ڵ������
const int colorNum = 15; // ��ɫ������

struct cc
{
    int id;
    int colorcnt;
};

struct node
{
    int id;
    int degree;
    int remain;
    int color[colorNum + 1];
    cc col[colorNum + 1];
} p[MAXN];

void init()
{
    for (int i = 1; i <= pointNum; i++)
    {
        for (int c = 1; c <= colorNum; c++)
        {
            p[i].color[c] = 1;
            p[i].col[c].id = c;
            p[i].col[c].colorcnt = 0;
        }
        p[i].id = i;
        p[i].remain = colorNum;
        p[i].degree = 0;
        color[i] = 0;
    }
}

/**
 * @brief �жϸýڵ��Ƿ���ʹ�������ɫ
 * 
 * @param x �ڵ�
 * @param c ��ɫ
 * @return true ����ʹ��
 * @return false �г�ͻ��������ʹ��
 */
bool check_color(int x, int c)
{
    for (int i = 1; i <= pointNum; i++)
    {
        if (graph[x][i] && color[i] == c)
        {
            return false;
        }
    }
    return true;
}

bool cmp(node x, node y)
{
    return x.degree > y.degree;
}

bool cmpcolor(cc x, cc y)
{
    return x.colorcnt < y.colorcnt;
}

int find_id(int i)
{
    for (int j = 1; j <= pointNum; j++)
    {
        if (i == p[j].id)
        {
            return j;
        }
    }
    return -1;
}

void select_dh()
{
    sort(p + 1, p + 1 + pointNum, cmp);
}

int select_mrv()
{
    int min_remain = colorNum + 1;
    int min_point = -1;
    for (int i = 1; i <= pointNum; i++)
    {
        if (p[i].remain < min_remain && color[p[i].id] == 0)
        {
            min_remain = p[i].remain;
            min_point = p[i].id;
        }
    }
    return min_point;
}

void color_sort(int t, int colorsort[])
{
    int index = find_id(t);
    for (int c = 1; c <= colorNum; c++)
    {
        for (int i = 1; i <= pointNum; i++)
        {
            if (graph[t][i] && color[i] == 0 && p[i].color[c] == 1)
            {
                p[index].col[c].colorcnt++;
            }
        }
    }
    cc tmp[colorNum + 1];
    for (int c = 1; c <= colorNum; c++)
    {
        tmp[c] = p[index].col[c];
    }

    sort(tmp + 1, tmp + 1 + colorNum, cmpcolor);

    for (int c = 1; c <= colorNum; c++)
    {
        colorsort[c] = tmp[c].id;
    }
}

void dfs_mrv_dh_display_mcv(int x)
{
    if (x > pointNum)
    {
        ans++;
        cout << ans << endl;
        return;
    }
    select_dh();
    int t = select_mrv();
    int index = find_id(t);
    if (t == -1)
        return;

    int colorsort[colorNum + 1];
    color_sort(t, colorsort);

    for (int c = 1; c <= colorNum; c++)
    {
        if (x == 1 && c == 2)
        {
            break;
        }
        int cc = colorsort[c];

        if (check_color(t, cc))
        {
            for (int i = 1; i <= pointNum; i++)
            {
                if (graph[t][i])
                {
                    int k = find_id(i);
                    p[k].degree--;
                    if (check_color(i, cc))
                    {
                        p[k].remain--;
                        p[k].color[cc] = 0;
                    }
                }
            }
            color[t] = cc;

            dfs_mrv_dh_display_mcv(x + 1);

            color[t] = 0;
            for (int i = 1; i <= pointNum; i++)
            {
                if (graph[t][i])
                {
                    int k = find_id(i);
                    p[k].degree++;
                    if (check_color(i, cc))
                    {
                        p[k].remain++;
                        p[k].color[cc] = 1;
                    }
                }
            }
        }
    }
}

int getEdgeData()
{
    ifstream inFile;
    inFile.open("450_15b.txt", ios::in);
    if (!inFile)
    {
        cout << "open failed" << endl;
        exit(1);
    }
    int cnt = 0, j = 0;
    while (!inFile.eof()) //�����ļ�������ʱ����true��
    {
        int a, b;
        inFile >> a >> b;
        edge[cnt][j++] = a;
        edge[cnt++][j] = b;
        j = 0;
    }
    inFile.close();
    return cnt;
}

int main()
{
    cout << "Points: " << pointNum << endl;
    cout << "Color: " << colorNum << endl;
    cout << "----------------------------------" << endl;

    init();

    int cnt = getEdgeData();
    for (int i = 0; i < cnt; i++)
    {
        graph[edge[i][0]][edge[i][1]] = 1;
        graph[edge[i][1]][edge[i][0]] = 1;
        p[find_id(edge[i][0])].degree++;
        p[find_id(edge[i][1])].degree++;
    }

    //CPUʱ�Ӽ�ʱ��Ԫ��
    clock_t start, finish;
    start = clock();
    dfs_mrv_dh_display_mcv(1);
    ans *= colorNum;
    finish = clock();

    cout << "Soluntions: " << endl;
    cout << ans << endl;
    cout << "----------------------------------" << endl;
    cout << "Time Cost: " << finish - start << endl;
    cout << "----------------------------------" << endl;

    system("pause");
    return 0;
}