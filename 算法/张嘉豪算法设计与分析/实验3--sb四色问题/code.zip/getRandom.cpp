#include <iostream>
#include <algorithm>
#include <random>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <fstream>

using namespace std;

/**
 * @brief ��������߼�
 * @param LOWER,UPPER �ߵķ�Χ
 * @param num ������=���ܶ�*(UPPER*(UPPER-1)/2)
 * @return 
 */

const int LOWER = 1;
const int UPPER = 50;
int num = 250;
uniform_int_distribution<unsigned> getRd(LOWER, UPPER);
default_random_engine e; //���������

struct node{
    int a;
    int b;
} p[9000];
bool cmp(node x,node y){
    if(x.a==y.a)
        return x.b < y.b;
    return x.a < y.a;
}
int main()
{

    ofstream inFile;
    inFile.open("50_m20.txt", ios::trunc);
    inFile.close();
    inFile.open("50_m20.txt", ios::app);

    for (int i = 1; i <= num; i++)
    {
        int x = getRd(e), y = getRd(e);
        if (x < y)
        {
            p[i].a = x, p[i].b = y;
        }
        else
        {
            i--;
        }
    }

    sort(p + 1, p + 1 + num, cmp);

    for (int i = 1; i <= num; i++)
    {
        inFile << p[i].a << " " << p[i].b << "\n";
    }
    inFile.close();

    //system("pause");
    return 0;
}