#include <iostream>
#include <algorithm>
#include <cstring>
#include <random>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <fstream>

using namespace std;
const int MAXN = 500;

int group[MAXN][MAXN]; // �ڽӾ����ʾͼ
int edge[9000][2];     // �߼�
int color[MAXN];       // �ڵ����ɫ״̬
int ans = 0;

const int pointNum = 450; // �ڵ������
const int colorNum = 15; // ��ɫ������

//CPUʱ�Ӽ�ʱ��Ԫ��
clock_t start, finish;

struct node
{
    int id;
    int degree;
    int remain;
} p[MAXN];

void init()
{
    for (int i = 1; i <= pointNum; i++)
    {
        p[i].id = i;
        p[i].remain = colorNum;
        p[i].degree = 0;
        color[i] = 0;
    }
}

/**
 * @brief �жϸýڵ��Ƿ���ʹ�������ɫ
 * 
 * @param x �ڵ�
 * @param c ��ɫ
 * @return true ����ʹ��
 * @return false �г�ͻ��������ʹ��
 */
bool check_color(int x, int c)
{
    for (int i = 1; i <= pointNum; i++)
    {
        if (group[x][i] && color[i] == c)
        {
            return false;
        }
    }
    return true;
}

bool cmp(node x, node y)
{
    return x.degree > y.degree;
}

int find_id(int i)
{
    for (int j = 1; j <= pointNum; j++)
    {
        if (i == p[j].id)
        {
            return j;
        }
    }
    return -1;
}

void select_dh()
{
    sort(p + 1, p + 1 + pointNum, cmp);
}

int select_mrv()
{
    int min_remain = colorNum + 1;
    int min_point = -1;
    for (int i = 1; i <= pointNum; i++)
    {
        if (p[i].remain < min_remain && color[p[i].id] == 0)
        {
            min_remain = p[i].remain;
            min_point = p[i].id;
        }
    }
    return min_point;
}

void dfs_mrv_dh(int x)
{
    if (x > pointNum)
    {
        ans++;
        if (ans == 1)
        {
            finish = clock();
            cout << "Soluntions: " << endl;
            cout << ans << endl;
            cout << "----------------------------------" << endl;
            cout << "Time Cost: " << finish - start << endl;
            cout << "----------------------------------" << endl;

            system("pause");
        }
        return;
    }
    select_dh();
    int t = select_mrv();
    if (t == -1)
        return;
    for (int c = 1; c <= colorNum; c++)
    {
        if (check_color(t, c))
        {
            for (int i = 1; i <= pointNum; i++)
            {
                if (group[t][i])
                {
                    int k = find_id(i);
                    p[k].degree--;
                    if (check_color(i, c))
                    {
                        p[k].remain--;
                    }
                }
            }
            color[t] = c;
            dfs_mrv_dh(x + 1);
            color[t] = 0;
            for (int i = 1; i <= pointNum; i++)
            {
                if (group[t][i])
                {
                    int k = find_id(i);
                    p[k].degree++;
                    if (check_color(i, c))
                    {
                        p[k].remain++;
                    }
                }
            }
        }
    }
}

/**
 * 
 * @brief ���ػ��ݷ�
 * 
 * @param x �ݹ����
 */
void dfs(int x)
{
    if (x > pointNum)
    {
        ans++;
        return;
    }
    for (int i = 1; i <= colorNum; i++)
    {
        if (check_color(x, i))
        {
            color[x] = i;
            dfs(x + 1);
            color[x] = 0;
        }
    }
}

int getEdgeData()
{
    ifstream inFile;
    inFile.open("450_15b.txt", ios::in);
    if (!inFile)
    {
        cout << "open failed" << endl;
        exit(1);
    }
    int cnt = 0, j = 0;
    while (!inFile.eof()) //�����ļ�������ʱ����true��
    {
        int a, b;
        inFile >> a >> b;
        edge[cnt][j++] = a;
        edge[cnt++][j] = b;
        j = 0;
    }
    inFile.close();
    return cnt;
}

int main()
{
    cout << "Points: " << pointNum << endl;
    cout << "Color: " << colorNum << endl;
    cout << "----------------------------------" << endl;

    init();

    int cnt = getEdgeData();
    for (int i = 0; i < cnt; i++)
    {
        group[edge[i][0]][edge[i][1]] = 1;
        group[edge[i][1]][edge[i][0]] = 1;
        p[find_id(edge[i][0])].degree++;
        p[find_id(edge[i][1])].degree++;
    }

    start = clock();
    dfs_mrv_dh(1);
    finish = clock();

    cout << "Soluntions: " << endl;
    cout << ans << endl;
    cout << "----------------------------------" << endl;
    cout << "Time Cost: " << finish - start << endl;
    cout << "----------------------------------" << endl;

    system("pause");
    return 0;
}