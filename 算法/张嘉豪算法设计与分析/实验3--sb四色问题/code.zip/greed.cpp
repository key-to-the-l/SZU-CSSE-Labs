#include <iostream>
#include <algorithm>
#include <random>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <fstream>

using namespace std;

int group[500][500]; // �ڽӾ����ʾͼ
int edge[8000][2];   // �߼�
int color[500];      // �ڵ����ɫ״̬
int ans = 0;
int newpoint[500];

const int pointNum = 50; // �ڵ������
const int colorNum = 4;  // ��ɫ������

struct Node
{
    int id;
    int value;
} point[500];

bool cmp(Node x, Node y)
{
    return x.value > y.value;
}

bool check_color(int x, int c)
{
    for (int i = 1; i <= pointNum; i++)
    {
        if (group[x][i] && color[i] == c)
        {
            return false;
        }
    }
    return true;
}

/**
 * @brief ̰�ļ�֦����
 * 
 * @param x �ݹ����
 */
void dfs(int x)
{
    if (x > pointNum)
    {
        ans++;
        return;
    }
    int p = newpoint[x];
    for (int i = 1; i <= colorNum; i++)
    {
        if (check_color(p, i))
        {
            color[p] = i;
            dfs(x + 1);
            color[p] = 0;
        }
    }
}

int getEdgeData()
{
    ifstream inFile;
    inFile.open("50.txt", ios::in);
    if (!inFile)
    {
        cout << "open failed" << endl;
        exit(1);
    }
    int cnt = 0, j = 0;
    while (!inFile.eof()) //�����ļ�������ʱ����true��
    {
        int a, b;
        inFile >> a >> b;
        edge[cnt][j++] = a;
        edge[cnt++][j] = b;
        j = 0;
    }
    inFile.close();
    return cnt;
}

int main()
{
    for (int i = 1; i <= pointNum; i++)
    {
        point[i].id = i;
    }
    cout << "Points: " << pointNum << endl;
    cout << "Color: " << colorNum << endl;
    cout << "----------------------------------" << endl;

    int cnt = getEdgeData();
    for (int i = 0; i < cnt; i++)
    {
        group[edge[i][0]][edge[i][1]] = 1;
        group[edge[i][1]][edge[i][0]] = 1;
        point[edge[i][0]].value++;
        point[edge[i][1]].value++;
    }

    //CPUʱ�Ӽ�ʱ��Ԫ��
    clock_t start, finish;
    

    sort(point + 1, point + 1 + pointNum, cmp);
    for (int i = 1; i <= pointNum; i++)
    {
        newpoint[i] = point[i].id;
    }
    start = clock();
    dfs(1);
    finish = clock();

    cout << "Soluntions: " << endl;
    cout << ans << endl;
    cout << "----------------------------------" << endl;
    cout << "Time Cost: " << finish - start << endl;
    cout << "----------------------------------" << endl;

    system("pause");
    return 0;
}