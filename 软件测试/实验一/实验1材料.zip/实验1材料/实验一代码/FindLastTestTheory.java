package szu.csse.softwaretesting.ch1;

import static org.junit.Assume.*;

import java.util.Arrays;

import static org.junit.Assert.*;

import org.junit.runner.RunWith;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.FromDataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;


@RunWith (Theories.class)
public class FindLastTestTheory {
	@DataPoints("arrays")
	public static int[][] arrs = {
			{2, 3, 5},
			{3, 3, 5},
			null,
			{4,5,6}
	};
	
	@DataPoints("ys")
	public static int[] ys = {2, 3, 5};
	//equivalent to the following three @DataPoint 	
	/*@DataPoint
	public static int y1 = 2;
	@DataPoint
	public static int y2 = 3;
	@DataPoint
	public static int y3 = 5;*/
	
	
	@Theory
	public void testNotInArray(@FromDataPoints("arrays") int[] arr, @FromDataPoints("ys") int y) {
		// Assume y is not in arr
		assumeNotNull(arr);
		assumeFalse(isInArray(arr,y));
		System.out.printf("In test4NotInArray: array = %s, y = %d\r\n", Arrays.toString(arr), y);
		int res = FindLast.findLast(arr, y);
		assertEquals("Last occurence not in array", -1, res);	
	}
	
	@Theory
	public void testInArray(int[] arr, int y) {
		// Assume y is in arr
		assumeNotNull(arr);
		assumeTrue(isInArray(arr,y)); 
		System.out.printf("In test4InArray: array = %s, y = %d\r\n", Arrays.toString(arr), y);
		int res = FindLast.findLast(arr, y);
		//res should be in [0, length)
		assertTrue( (res >= 0) && (res < arr.length));
		//y should not in array[res+1, length)
		assertFalse(isInArray(subArray(arr, res+1), y) );	
	}
	
	@Theory
	public void test4NullArray(int[]arr, int y) {
		assumeTrue(arr == null);
		try {
			System.out.printf("In test4NullArray: array = %s, y = %d\r\n", Arrays.toString(arr), y);
			FindLast.findLast(arr, y);
		}catch (NullPointerException e) {
				return;
		}
		fail("NullPointerException expected");
	}
		
	private boolean isInArray(int[] arr, int y) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == y) return true;
		}
		return false;
	}
	
	private int[] subArray(int[] arr, int start) {
		if (arr == null) return null;
		int len = arr.length - start;
		if (len < 0) len = 0;
		int[] subarr = new int[len];
		for(int i = 0; i < len; i++) {
			subarr[i] = arr[start+i];
		}
		return subarr;	
	}

   /*
   private void print(int[]  arr, int y) {
		System.out.print("Array: ");
		if(arr == null) {
			System.out.print("null");
		}
		else {
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]);
				System.out.print(",");
			}
		}
		System.out.println("");
		System.out.print("Y: ");
		System.out.println(y);	
	}*/
	
}
