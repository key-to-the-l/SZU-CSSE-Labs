package szu.csse.softwaretesting.ch1;

import static org.junit.Assert.*;

import org.junit.Test;

//import static org.junit.Assert.*;

//import org.junit.Test;

public class FindLastTest {
	
	//This test fails for the original program!
	@Test 
	public void lastOccurrenceInFirstElement() {
		int arr[] = {2, 3, 5};
	    int y = 2;
	    int res = FindLast.findLast(arr, y);
	    assertEquals("Last occurence in first element", 0, res);
	 }
	
	//This test does not execute the fault, but with an exception.
	// Catch the exception implicitly by @expected.
	@Test (expected = NullPointerException.class)
	public void nullArray() {
		int[] arr = null;
		int y = 2;
		FindLast.findLast(arr, y);
	}
	
	//This test does not execute the fault, but with an exception.
	// Catch the exception explicitly.
	@Test 
	public void nullArray1() {
		int[] arr = null;
		int y = 2;
		try {
			FindLast.findLast(arr, y);
		}catch (NullPointerException e) {
			return;
		}
		fail("NullPointerException expected");
	}
	
	//This test executes the fault, but does not result in an error state. 
	@Test 
	public void lastOccurrenceInNonFirstElement() {
		int arr[] = {2, 3, 5};
	    int y = 3;
	    int res = FindLast.findLast(arr, y);
	    assertEquals("Last occurence in non-first element", 1,res);
	 }
	
	//This test results in an error state, but not a failure!
	@Test 
	public void lastOccurrenceNotInArray() {
		int arr[] = {2, 3, 5};
	    int y = 1;
	    int res = FindLast.findLast(arr, y);
	    assertEquals("Last occurence not in array", -1, res);
	 }

}
