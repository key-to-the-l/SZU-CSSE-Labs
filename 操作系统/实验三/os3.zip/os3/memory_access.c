#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MB (1024 * 1024)
#define KB (1024)
#define MEMORY_SIZE (256 * MB)  // 分配256MB内存
#define PAGE_SIZE (4 * KB)      // 4KB页面大小

void print_memory_status() {
    char status_path[64];
    sprintf(status_path, "/proc/%d/status", getpid());
    
    printf("\n当前进程状态 (/proc/%d/status):\n", getpid());
    char command[128];
    sprintf(command, "grep 'Vm' %s", status_path);
    system(command);
}

int main() {
    // 分配内存前的状态
    printf("初始状态:\n");
    print_memory_status();
    
    // 分配256MB内存
    char* memory = (char*)malloc(MEMORY_SIZE);
    if (memory == NULL) {
        printf("内存分配失败！\n");
        return 1;
    }
    printf("\n分配256MB内存后的状态:\n");
    print_memory_status();

    // 每隔4KB进行读操作
    printf("\n每隔4KB进行读操作...\n");
    char temp;
    for (size_t i = 0; i < MEMORY_SIZE; i += PAGE_SIZE) {
        temp = memory[i];  // 读操作
    }
    printf("\n读操作后的状态:\n");
    print_memory_status();
    
    // 每隔4KB进行写操作
    printf("\n每隔4KB进行写操作...\n");
    for (size_t i = 0; i < MEMORY_SIZE; i += PAGE_SIZE) {
        memory[i] = 1;  // 写操作
    }
    printf("\n写操作后的状态:\n");
    print_memory_status();
    
    // 清理内存
    free(memory);
    
    return 0;
}
