#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define GB (1024L * 1024L * 1024L)
#define MB (1024L * 1024L)

void print_memory_status() {
    char status_path[64];
    sprintf(status_path, "/proc/%d/status", getpid());
    
    printf("\n当前进程状态 (/proc/%d/status):\n", getpid());
    char command[128];
    sprintf(command, "grep 'Vm' %s", status_path);
    system(command);
}

void print_maps() {
    char maps_path[64];
    sprintf(maps_path, "/proc/%d/maps", getpid());
    
    printf("\n当前进程内存映射 (/proc/%d/maps):\n", getpid());
    char command[128];
    sprintf(command, "cat %s", maps_path);
    system(command);
}

int main() {
    unsigned long total_allocated = 0;
    // 从1GB开始
    unsigned long allocation_size = 1 * GB; 
    void* memory = NULL;
    
    printf("开始测试最大虚拟内存分配...\n");
    print_memory_status();
    
    while (1) {
        memory = malloc(allocation_size);
        
        if (memory == NULL) {
            // 如果分配失败，尝试更小的大小
            allocation_size /= 2;
            // 如果分配大小小于1MB，则退出
            if (allocation_size < MB) { 
                break;
            }
            continue;
        }

        // 写入字符
        memset(memory, 'A', allocation_size);
        
        total_allocated += allocation_size;
        printf("成功分配 %lu MB内存,总计: %lu MB\n", allocation_size / MB, total_allocated / MB);
    }

    printf("\n最终分配结果:\n");
    printf("总共分配: %lu MB (%lu GB)\n", 
           total_allocated / MB, total_allocated / GB);
    
    print_memory_status();
    print_maps();
    
    return 0;
}
