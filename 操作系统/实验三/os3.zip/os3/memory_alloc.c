#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MB (1024 * 1024)

void print_memory_status() {
    char status_path[64];
    sprintf(status_path, "/proc/%d/status", getpid());
    printf("\n当前进程状态 (/proc/%d/status):\n", getpid());
    char command[128];
    sprintf(command, "grep 'Vm' %s", status_path);
    system(command);
}

void print_maps() {
    char maps_path[64];
    sprintf(maps_path, "/proc/%d/maps", getpid());
    printf("\n当前进程内存映射 (/proc/%d/maps):\n", getpid());
    char command[128];
    sprintf(command, "cat %s", maps_path);
    system(command);
}

int main() {
    void* memory[6];
    
    printf("初始状态:\n");
    print_memory_status();
    print_maps();
    
    // 连续分配6个128MB空间
    for(int i = 0; i < 6; i++) {
        memory[i] = malloc(128 * MB);
        if (memory[i] == NULL) {
            printf("分配第%d块128MB内存失败\n", i + 1);
            return 1;
        }
        // 写入一些数据以确保物理内存被分配
        memset(memory[i], 1, 128 * MB);
        printf("\n分配第%d块128MB内存后:\n", i + 1);
        print_memory_status();
        print_maps();
    }
    
    // 释放2、3、5号空间
    free(memory[1]);
    free(memory[2]);
    free(memory[4]);
    printf("\n释放2、3、5号空间后:\n");
    print_memory_status();
    print_maps();
    
    // 尝试分配1024MB
    printf("\n尝试分配1024MB空间:\n");
    void* large_memory = malloc(1024 * MB);
    if (large_memory == NULL) {
        printf("分配1024MB内存失败\n");
    } else {
        memset(large_memory, 1, 1024 * MB);
        printf("分配1024MB内存成功\n");
        print_memory_status();
        print_maps();
    }
    
    // 尝试分配64MB并观察其位置
    printf("\n尝试分配64MB空间:\n");
    void* test_memory = malloc(64 * MB);
    if (test_memory == NULL) {
        printf("分配64MB内存失败\n");
    } else {
        memset(test_memory, 1, 64 * MB);
        printf("分配64MB内存成功,地址: %p\n", test_memory);
        print_memory_status();
        print_maps();
    }
    
    // 清理剩余内存
    free(memory[0]);
    free(memory[3]);
    free(memory[5]);
    free(large_memory);
    free(test_memory);
    
    return 0;
}
