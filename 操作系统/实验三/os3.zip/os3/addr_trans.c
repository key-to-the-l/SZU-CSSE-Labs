#include <stdio.h>

// 全局变量
int global_var = 42;

// 自定义函数
void custom_function() {
    printf("这是一个自定义函数\n");
}

int main() {
    printf("全局变量地址: %p\n", (void*)&global_var);
    printf("自定义函数地址: %p\n", (void*)custom_function);
    
    custom_function();
    return 0;
}