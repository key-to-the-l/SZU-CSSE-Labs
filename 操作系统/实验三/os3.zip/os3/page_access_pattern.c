#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

#define GB ((size_t)1024 * 1024 * 1024)
#define MB ((size_t)1024 * 1024)
#define KB ((size_t)1024)
#define PAGE_SIZE (4 * KB)          // 4KB页面大小
#define GROUP_SIZE (16 * PAGE_SIZE)  // 16页为一组
#define MEMORY_SIZE (3 * GB)         // 分配3GB内存
#define ACCESS_TIMES 3               // 访问次数

// 顺序访问模式
double sequential_access(char* memory) {
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    for (int t = 0; t < ACCESS_TIMES; t++) {
        for (size_t i = 0; i < MEMORY_SIZE; i += PAGE_SIZE) {
            memory[i] = 1;  // 写入操作
        }
    }
    
    gettimeofday(&end, NULL);
    return (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
}

// 组访问模式
double group_access(char* memory) {
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    for (int t = 0; t < ACCESS_TIMES; t++) {
        for (size_t i = 0; i < MEMORY_SIZE; i += GROUP_SIZE) {
            // 访问一组16个连续页
            for (size_t j = i; j < i + GROUP_SIZE && j < MEMORY_SIZE; j += PAGE_SIZE) {
                memory[j] = 1;  // 写入操作
            }
        }
    }
    
    gettimeofday(&end, NULL);
    return (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
}

int main() {
    // 分配大内存
    char* memory = (char*)malloc(MEMORY_SIZE);
    if (memory == NULL) {
        printf("内存分配失败！\n");
        return 1;
    }
    printf("\n分配%zuGB内存后:\n", MEMORY_SIZE / GB);
    
    // 初始化内存
    printf("\n初始化内存...\n");
    for (size_t i = 0; i < MEMORY_SIZE; i += PAGE_SIZE) {
        memory[i] = 0;
    }
    
    // 测试顺序访问模式
    printf("\n开始顺序访问测试(每4KB一次)...\n");
    double sequential_time = sequential_access(memory);
    printf("顺序访问完成，用时: %.2f秒\n", sequential_time);
    
    sleep(5);  // 等待系统状态稳定
    
    // 测试组访问模式
    printf("\n开始组访问测试(每16页为一组)...\n");
    double group_time = group_access(memory);
    printf("组访问完成，用时: %.2f秒\n", group_time);
    
    // 比较结果
    printf("\n===== 结果比较 =====\n");
    printf("顺序访问时间: %.2f秒\n", sequential_time);
    printf("组访问时间: %.2f秒\n", group_time);
    printf("时间差异: %.2f秒 (%.2f%%)\n", 
           group_time - sequential_time,
           (group_time - sequential_time) * 100 / sequential_time);
    
    free(memory);
    return 0;
}
