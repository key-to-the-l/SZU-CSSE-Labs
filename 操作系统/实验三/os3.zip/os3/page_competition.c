#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define GB ((size_t)1024 * 1024 * 1024)
#define MB ((size_t)1024 * 1024)
#define KB ((size_t)1024)
#define FIRST_PROC_MEM (1 * GB)   // 第一个进程分配1GB内存
#define SECOND_PROC_MEM (2 * GB)  // 第二个进程分配2GB内存
#define PAGE_SIZE (4 * KB)          // 4KB页面大小

void print_proc_status(int pid) {
    printf("\n进程 %d 的状态 (/proc/%d/status):\n", pid, pid);
    char command[128];
    sprintf(command, "grep 'Vm' /proc/%d/status", pid);
    system(command);
}

void print_proc_smaps(int pid) {
    printf("\n进程 %d 的内存映射 (/proc/%d/smaps):\n", pid, pid);
    char command[128];
    sprintf(command, "grep -A 15 'heap' /proc/%d/smaps", pid);
    system(command);
}

void print_system_memory() {
    printf("\n系统内存使用情况 (/proc/meminfo):\n");
    system("grep 'Mem\\|Swap' /proc/meminfo");
}

void first_process() {
    printf("\n第一个进程(PID: %d)开始运行...\n", getpid());
    
    // 分配内存
    char* memory = (char*)malloc(FIRST_PROC_MEM);
    if (memory == NULL) {
        printf("第一个进程内存分配失败！\n");
        exit(1);
    }
    
    // 使用内存
    printf("\n第一个进程正在使用内存...\n");
    for (size_t i = 0; i < FIRST_PROC_MEM; i += PAGE_SIZE) {
        memory[i] = 1;  // 写入数据以确保物理页面被分配
    }
    print_proc_status(getpid());
    print_proc_smaps(getpid());
    print_system_memory();
    
    // 保持运行并持续访问内存
    printf("\n第一个进程持续访问内存中...\n");
    while (1) {
        for (size_t i = 0; i < FIRST_PROC_MEM; i += PAGE_SIZE) {
            memory[i] = 2; 
            usleep(1000);
        }
    }
}

void second_process() {
    printf("\n第二个进程(PID: %d)开始运行...\n", getpid());
    
    // 分配更多内存
    char* memory = (char*)malloc(SECOND_PROC_MEM);
    if (memory == NULL) {
        printf("第二个进程内存分配失败！\n");
        exit(1);
    }
    
    // 大量使用内存
    printf("\n第二个进程正在大量使用内存...\n");
    for (size_t i = 0; i < SECOND_PROC_MEM; i += PAGE_SIZE) {
        memory[i] = 1;  // 写入数据以确保物理页面被分配
        if (i % (64 * MB) == 0) {  // 每64MB显示一次状态
            print_proc_status(getpid());
            print_system_memory();
        }
    }
    print_proc_smaps(getpid());
    
    // 持续使用内存一段时间
    printf("\n第二个进程持续使用内存中...\n");
    for (int i = 0; i < 10; i++) {
        for (size_t j = 0; j < SECOND_PROC_MEM; j += PAGE_SIZE) {
            memory[j] = 2;
        }
        sleep(1);
    }
}

int main() {
    printf("初始状态:\n");
    print_system_memory();
    
    pid_t pid = fork();
    if (pid < 0) {
        printf("进程创建失败！\n");
        return 1;
    }
    
    if (pid == 0) {
        // 子进程运行第一个进程的代码
        first_process();
    } else {
        // 父进程等待一段时间，让第一个进程稳定运行
        sleep(5);
        // 创建第二个子进程
        pid_t pid2 = fork();
        if (pid2 < 0) {
            printf("第二个进程创建失败！\n");
            return 1;
        }
        if (pid2 == 0) {
            // 新的子进程运行第二个进程的代码
            second_process();
            exit(0);
        } else {
            // 父进程等待第二个子进程结束
            waitpid(pid2, NULL, 0);
            // 终止第一个子进程
            kill(pid, SIGTERM);
            waitpid(pid, NULL, 0);
        }
    }
    
    return 0;
}
