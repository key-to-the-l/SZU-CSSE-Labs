#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>


int main() {
    int num_layers = 50;
    pid_t pid = getpid();
    pid_t c_pid = getpid();
    for (int i = 0; i < num_layers; i++) {
        c_pid = pid + i;
        if (c_pid == getpid()) {
            pid_t pid = fork();
            if (pid) {
                break;
            }
        }
        //�����̼���������һ���ӽ���
    }

        sleep(30);
    return 0;
}