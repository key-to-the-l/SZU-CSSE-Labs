#include <stdio.h>
int main() {
    while (1) {
        printf("Hello World!\n");
    }
    return 0;
}