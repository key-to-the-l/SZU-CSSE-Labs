#include <stdio.h>
#include <unistd.h>

int main() {
    fork();
    getchar();
    return 0;

}