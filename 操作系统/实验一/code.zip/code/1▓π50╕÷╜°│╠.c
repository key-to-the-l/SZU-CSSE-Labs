#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    int num_processes = 50;
    pin_t pid;

    for (int i = 0; i < num_processes; i++) {
        pid = fork();
        if (pid == 0) {
            //���ӽ�����ִ�еĴ���
            printf("Child process %d created.\n", getpid());
            break;
        }else if (pid < 0) {  
            printf("Error occurred while forking.\n");
            break;
        }else {  
            // �ڸ�������ִ�еĴ���
            printf("Parent process %d created child process %d.\n", getpid(), pid);
        }
    } 
        sleep(30);
    return 0;
}
    