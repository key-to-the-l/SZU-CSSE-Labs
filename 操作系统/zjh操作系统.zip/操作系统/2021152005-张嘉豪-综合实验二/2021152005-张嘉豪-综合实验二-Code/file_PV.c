#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/wait.h>

#define SHM_NAME "/my_shared_memory"
#define SHM_SIZE (100 * 1024 * 1024)  // 100MB

#define INODE_COUNT 1024
#define BLOCK_SIZE 4096
#define BLOCK_COUNT (SHM_SIZE / BLOCK_SIZE)

#define MAX_FILE_NAME 28

typedef struct {
    int size;
    int block_count;
    int inode_count;
    int free_blocks;
    int free_inodes;
    int block_bitmap_offset;
    int inode_bitmap_offset;
    int inode_table_offset;
    int data_blocks_offset;
} Superblock;

typedef struct {
    int size;
    int direct_blocks[10];
} Inode;

typedef struct {
    char name[MAX_FILE_NAME];
    int inode_number;
} DirectoryEntry;

// 信号量和读者计数器
sem_t rw_mutex;
sem_t mutex;
int read_count = 0;

void initialize_filesystem(void *shm_ptr) {
    Superblock *sb = (Superblock *)shm_ptr;
    sb->size = SHM_SIZE;
    sb->block_count = BLOCK_COUNT;
    sb->inode_count = INODE_COUNT;
    sb->free_blocks = BLOCK_COUNT - 1;  // 减去超级块
    sb->free_inodes = INODE_COUNT;

    sb->block_bitmap_offset = sizeof(Superblock);
    sb->inode_bitmap_offset = sb->block_bitmap_offset + BLOCK_COUNT / 8;
    sb->inode_table_offset = sb->inode_bitmap_offset + INODE_COUNT / 8;
    sb->data_blocks_offset = sb->inode_table_offset + INODE_COUNT * sizeof(Inode);

    memset(shm_ptr + sb->block_bitmap_offset, 0, BLOCK_COUNT / 8);
    memset(shm_ptr + sb->inode_bitmap_offset, 0, INODE_COUNT / 8);
}

int open_file(void *shm_ptr, const char *filename, int size) {
    Superblock *sb = (Superblock *)shm_ptr;
    Inode *inode_table = (Inode *)(shm_ptr + sb->inode_table_offset);
    for (int i = 0; i < sb->inode_count; i++) {
        if (inode_table[i].size == 0) { // 找到一个空的 inode
            inode_table[i].size = size;
            // 假设只使用一个直接块
            inode_table[i].direct_blocks[0] = sb->data_blocks_offset / BLOCK_SIZE + i;
            DirectoryEntry *entry = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset + i * sizeof(DirectoryEntry));
            strncpy(entry->name, filename, MAX_FILE_NAME);
            entry->inode_number = i;
            sb->free_inodes--;
            return i;
        }
    }
    return -1;
}

void modify_file(void *shm_ptr, const char *filename, const char *content) {
    Superblock *sb = (Superblock *)shm_ptr;
    Inode *inode_table = (Inode *)(shm_ptr + sb->inode_table_offset);

    for (int i = 0; i < sb->inode_count; i++) {
        if (inode_table[i].size > 0) { // 假设 size > 0 表示 inode 被使用
            DirectoryEntry *entry = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset + i * sizeof(DirectoryEntry));
            if (strcmp(entry->name, filename) == 0) {
                sem_wait(&rw_mutex); // 申请写锁
                strncpy((char *)(shm_ptr + inode_table[i].direct_blocks[0] * BLOCK_SIZE), content, strlen(content));
                sem_post(&rw_mutex); // 释放写锁
                printf("修改文件 %s 内容成功\n", filename);
                return;
            }
        }
    }
    printf("文件 %s 不存在\n", filename);
}

void read_file(void *shm_ptr, const char *filename) {
    Superblock *sb = (Superblock *)shm_ptr;
    Inode *inode_table = (Inode *)(shm_ptr + sb->inode_table_offset);

    for (int i = 0; i < sb->inode_count; i++) {
        if (inode_table[i].size > 0) {
            DirectoryEntry *entry = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset + i * sizeof(DirectoryEntry));
            if (strcmp(entry->name, filename) == 0) {
                sem_wait(&mutex); // 申请读计数器锁
                read_count++;
                if (read_count == 1) {
                    sem_wait(&rw_mutex); // 第一个读者锁写
                }
                sem_post(&mutex); // 释放读计数器锁

                printf("读取文件 %s 内容: %s\n", filename, (char *)(shm_ptr + inode_table[i].direct_blocks[0] * BLOCK_SIZE));

                sem_wait(&mutex); // 申请读计数器锁
                read_count--;
                if (read_count == 0) {
                    sem_post(&rw_mutex); // 最后一个读者释放写锁
                }
                sem_post(&mutex); // 释放读计数器锁
                return;
            }
        }
    }
    printf("文件 %s 不存在\n", filename);
}

void ls(void *shm_ptr) {
    Superblock *sb = (Superblock *)shm_ptr;
    Inode *inode_table = (Inode *)(shm_ptr + sb->inode_table_offset);
    for (int i = 0; i < sb->inode_count; i++) {
        if (inode_table[i].size > 0) {
            DirectoryEntry *entry = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset + i * sizeof(DirectoryEntry));
            printf("文件名: %s, 大小: %d 字节\n", entry->name, inode_table[i].size);
        }
    }
}

int main() {
    // 创建共享内存对象
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // 调整共享内存对象的大小
    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("ftruncate");
        exit(EXIT_FAILURE);
    }

    // 将共享内存映射到进程地址空间
    void *shm_ptr = mmap(0, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    printf("共享内存创建并映射成功。\n");

    // 初始化文件系统
    initialize_filesystem(shm_ptr);

    // 初始化信号量
    sem_init(&rw_mutex, 1, 1);
    sem_init(&mutex, 1, 1);

    // 测试函数
    if (fork() == 0) {
        // 子进程1：读文件
        sleep(1); // 确保写操作先执行
        read_file(shm_ptr, "testfile.txt");
        exit(0);
    } else if (fork() == 0) {
        // 子进程2：修改文件内容
        modify_file(shm_ptr, "testfile.txt", "新的内容");
        exit(0);
    } else {
        // 父进程：创建文件并写入内容
        open_file(shm_ptr, "testfile.txt", 1024);
        modify_file(shm_ptr, "testfile.txt", "初始内容");

        // 等待子进程结束
        wait(NULL);
        wait(NULL);

        // 查看文件系统目录结构
        ls(shm_ptr);
    }

    // 解除映射并关闭共享内存对象
    if (munmap(shm_ptr, SHM_SIZE) == -1) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }

    if (close(shm_fd) == -1) {
        perror("close");
        exit(EXIT_FAILURE);
    }

    // 删除共享内存对象
    if (shm_unlink(SHM_NAME) == -1) {
        perror("shm_unlink");
        exit(EXIT_FAILURE);
    }

    // 销毁信号量
    sem_destroy(&rw_mutex);
    sem_destroy(&mutex);

    return 0;
}

