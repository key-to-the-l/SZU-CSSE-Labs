#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#define SHM_NAME "/my_fs_shared_memory"
#define SHM_SIZE (100 * 1024 * 1024)  // 100MB

#define INODE_COUNT 1024
#define BLOCK_SIZE 4096
#define BLOCK_COUNT (SHM_SIZE / BLOCK_SIZE)

#define MAX_FILE_NAME 28

typedef struct {
    int size;
    int block_count;
    int inode_count;
    int free_blocks;
    int free_inodes;
    int block_bitmap_offset;
    int inode_bitmap_offset;
    int inode_table_offset;
    int data_blocks_offset;
} Superblock;

typedef struct {
    int size;
    int direct_blocks[10];
} Inode;

typedef struct {
    char name[MAX_FILE_NAME];
    int inode_number;
} DirectoryEntry;

// 初始化文件系统
void initialize_filesystem(void *shm_ptr) {
    Superblock *sb = (Superblock *)shm_ptr;
    sb->size = SHM_SIZE;
    sb->block_count = BLOCK_COUNT;
    sb->inode_count = INODE_COUNT;
    sb->free_blocks = BLOCK_COUNT - 1;  // 减去超级块
    sb->free_inodes = INODE_COUNT;

    sb->block_bitmap_offset = sizeof(Superblock);
    sb->inode_bitmap_offset = sb->block_bitmap_offset + BLOCK_COUNT / 8;
    sb->inode_table_offset = sb->inode_bitmap_offset + INODE_COUNT / 8;
    sb->data_blocks_offset = sb->inode_table_offset + INODE_COUNT * sizeof(Inode);

    memset(shm_ptr + sb->block_bitmap_offset, 0, BLOCK_COUNT / 8);
    memset(shm_ptr + sb->inode_bitmap_offset, 0, INODE_COUNT / 8);
}

// 创建目录
int mkdir(void *shm_ptr, const char *dirname) {
    Superblock *sb = (Superblock *)shm_ptr;
    if (sb->free_inodes <= 0) {
        printf("No enough space for directories.\n");
        return -1;
    }

    // 分配一个新的inode
    unsigned char *inode_bitmap = shm_ptr + sb->inode_bitmap_offset;
    int inode_number;
    for (inode_number = 0; inode_number < INODE_COUNT; inode_number++) {
        if (!(inode_bitmap[inode_number / 8] & (1 << (inode_number % 8)))) {
            inode_bitmap[inode_number / 8] |= (1 << (inode_number % 8));
            sb->free_inodes--;
            break;
        }
    }

    if (inode_number == INODE_COUNT) {
        printf("Failed to allocate inode for directory.\n");
        return -1;
    }

    // 更新目录条目
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number == 0) {
            strncpy(root_dir[i].name, dirname, MAX_FILE_NAME);
            root_dir[i].inode_number = inode_number;
            break;
        }
    }

    return 0;
}

// 删除目录
int rmdir(void *shm_ptr, const char *dirname) {
    Superblock *sb = (Superblock *)shm_ptr;
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number != 0 && strcmp(root_dir[i].name, dirname) == 0) {
            int inode_number = root_dir[i].inode_number;

            // 检查目录是否为空
            DirectoryEntry *dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
            int empty = 1;
            for (int j = 0; j < INODE_COUNT; j++) {
                if (dir[j].inode_number != 0) {
                    empty = 0;
                    break;
                }
            }
            if (!empty) {
                printf("Directory not empty: %s\n", dirname);
                return -1;
            }

            // 删除目录条目
            root_dir[i].inode_number = 0;

            // 释放i节点
            unsigned char *inode_bitmap = shm_ptr + sb->inode_bitmap_offset;
            inode_bitmap[inode_number / 8] &= ~(1 << (inode_number % 8));
            sb->free_inodes++;
            return 0;
        }
    }
    printf("Directory not found: %s\n", dirname);
    return -1;
}

// rename
int rename_file(void *shm_ptr, const char *oldname, const char *newname) {
    Superblock *sb = (Superblock *)shm_ptr;
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number != 0 && strcmp(root_dir[i].name, oldname) == 0) {
            strncpy(root_dir[i].name, newname, MAX_FILE_NAME);
            return 0;
        }
    }
    printf("File not found: %s\n", oldname);
    return -1;
}

// 创建文件
int open_file(void *shm_ptr, const char *filename, int size) {
    Superblock *sb = (Superblock *)shm_ptr;
    if (sb->free_inodes <= 0 || sb->free_blocks < (size + BLOCK_SIZE - 1) / BLOCK_SIZE) {
        printf("No enough space or inodes.\n");
        return -1;
    }

    // 分配一个新的inode
    unsigned char *inode_bitmap = shm_ptr + sb->inode_bitmap_offset;
    int inode_number;
    for (inode_number = 0; inode_number < INODE_COUNT; inode_number++) {
        if (!(inode_bitmap[inode_number / 8] & (1 << (inode_number % 8)))) {
            inode_bitmap[inode_number / 8] |= (1 << (inode_number % 8));
            sb->free_inodes--;
            break;
        }
    }

    if (inode_number == INODE_COUNT) {
        printf("Failed to allocate inode.\n");
        return -1;
    }

    Inode *inodes = (Inode *)(shm_ptr + sb->inode_table_offset);
    Inode *new_inode = &inodes[inode_number];
    new_inode->size = size;
    int blocks_needed = (size + BLOCK_SIZE - 1) / BLOCK_SIZE;

    unsigned char *block_bitmap = shm_ptr + sb->block_bitmap_offset;
    for (int i = 0; i < blocks_needed; i++) {
        int block_number;
        for (block_number = 0; block_number < BLOCK_COUNT; block_number++) {
            if (!(block_bitmap[block_number / 8] & (1 << (block_number % 8)))) {
                block_bitmap[block_number / 8] |= (1 << (block_number % 8));
                sb->free_blocks--;
                new_inode->direct_blocks[i] = sb->data_blocks_offset / BLOCK_SIZE + block_number;
                break;
            }
        }
        if (block_number == BLOCK_COUNT) {
            printf("Failed to allocate block.\n");
            return -1;
        }
    }

    // 根目录添加文件条目
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number == 0) {
            strncpy(root_dir[i].name, filename, MAX_FILE_NAME);
            root_dir[i].inode_number = inode_number;
            break;
        }
    }

    return 0;
}

// 删除文件
int rm_file(void *shm_ptr, const char *filename) {
    Superblock *sb = (Superblock *)shm_ptr;
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number != 0 && strcmp(root_dir[i].name, filename) == 0) {
            int inode_number = root_dir[i].inode_number;
            root_dir[i].inode_number = 0;

            Inode *inodes = (Inode *)(shm_ptr + sb->inode_table_offset);
            Inode *inode = &inodes[inode_number];
            for (int j = 0; j < (inode->size + BLOCK_SIZE - 1) / BLOCK_SIZE; j++) {
                int block_number = inode->direct_blocks[j] - sb->data_blocks_offset / BLOCK_SIZE;
                unsigned char *block_bitmap = shm_ptr + sb->block_bitmap_offset;
                block_bitmap[block_number / 8] &= ~(1 << (block_number % 8));
                sb->free_blocks++;
            }
            inode->size = 0;
            memset(inode->direct_blocks, 0, sizeof(inode->direct_blocks));

            unsigned char *inode_bitmap = shm_ptr + sb->inode_bitmap_offset;
            inode_bitmap[inode_number / 8] &= ~(1 << (inode_number % 8));
            sb->free_inodes++;
            printf("File deleted: %s\n", filename);
            return 0;
        }
    }
    printf("File not found: %s\n", filename);
    return -1;
}

// 查看文件系统目录结构
void ls(void *shm_ptr) {
    Superblock *sb = (Superblock *)shm_ptr;
    DirectoryEntry *root_dir = (DirectoryEntry *)(shm_ptr + sb->data_blocks_offset);
    for (int i = 0; i < INODE_COUNT; i++) {
        if (root_dir[i].inode_number != 0) {
            printf("File: %s, Inode: %d\n", root_dir[i].name, root_dir[i].inode_number);
        }
    }
}

int main() {
    // 创建共享内存对象
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // 调整共享内存对象的大小
    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("ftruncate");
        exit(EXIT_FAILURE);
    }

    // 将共享内存映射到进程地址空间
    void *shm_ptr = mmap(0, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    printf("共享内存创建并映射成功。\n");

    // 初始化文件系统
    initialize_filesystem(shm_ptr);

    // 测试文件系统操作
    mkdir(shm_ptr, "dir1");
    mkdir(shm_ptr, "dir2");
    open_file(shm_ptr, "file1.txt", 1024);
    open_file(shm_ptr, "file2.txt", 2048);
    rename_file(shm_ptr, "file1.txt", "file3.txt");
    ls(shm_ptr);
    rm_file(shm_ptr, "file2.txt");
    rmdir(shm_ptr, "dir1");

    // 解除映射并关闭共享内存对象
    if (munmap(shm_ptr, SHM_SIZE) == -1) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }

    if (close(shm_fd) == -1) {
        perror("close");
        exit(EXIT_FAILURE);
    }

    // 删除共享内存对象
    if (shm_unlink(SHM_NAME) == -1) {
        perror("shm_unlink");
        exit(EXIT_FAILURE);
    }

    return 0;
}

