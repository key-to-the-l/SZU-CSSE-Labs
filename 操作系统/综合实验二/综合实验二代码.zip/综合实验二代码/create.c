#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#define SHM_SIZE 104857600 // 100MB, 1MB = 1048576 bytes
#define SHM_NAME "/my_shared_memory"

int main() {
    // 创建或打开一个共享内存对象
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("Failed to create shared memory");
        return 1;
    }

    // 设置共享内存的大小为 100MB
    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("Failed to set size of shared memory");
        close(shm_fd);
        return 1;
    }

    // 将共享内存映射到进程的地址空间
    void *shm_ptr = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("Failed to map shared memory");
        close(shm_fd);
        return 1;
    }

    printf("100MB shared memory created successfully.\n");


    // 取消内存映射
    munmap(shm_ptr, SHM_SIZE);
    // 关闭共享内存文件描述符
    close(shm_fd);
    // 删除共享内存对象
    shm_unlink(SHM_NAME);

    return 0;
}

