import numpy as np
import matplotlib.pyplot as plt

T = 10      # 时隙数量
Pmax = 1    # 发射功率上限

# 随机生成 a 的值
#a = np.random.rand(10)
a = np.array([0.7962, 0.6912, 0.3453, 0.9468, 0.5202, 0.9538, 0.0736, 0.2070, 0.7750, 0.9142])
b = np.ones(1)
inverse_a = b/a

# 初始 iterlamda
iterlamda = T / (1 + np.sum(inverse_a))

# 迭代次数
num_iterations = 10

for j in range(num_iterations):
    # 遍历功率分配，如果存在不符合条件的，将对应的信道置零
    for i in range(num_iterations):
        if inverse_a[i] != 0 and 1 / iterlamda < inverse_a[i]:
            inverse_a[i]= 0
            T-=1

    # 重新计算 iterlamda
    iterlamda = T / (1 + np.sum(inverse_a))

# 计算发射功率分配
p = np.maximum(1 / iterlamda - 1 / a, 0)


# 输出结果
print("总信道容量：", np.sum(np.log2(1 + p * a)))
# 以两列形式输出一组数据
combined_data = np.column_stack((a, p))
print("     ai          pi\n", combined_data)

# 绘制图形
T = 10      # 恢复T的值
fig, ax = plt.subplots()
ax.bar(range(1, T+1), 1/a[:T], label='1/a', alpha=0.7 , width=0.7)
ax.bar(range(1, T+1), p[:T], label='pi', alpha=0.7 , width=0.7, bottom=1/a[:T])
ax.axhline(y=1 /iterlamda, color='r', linestyle='--', label='Water filling line')
ax.set_xlabel('time')
ax.set_ylabel('1/ai')
ax.legend()
plt.show()
