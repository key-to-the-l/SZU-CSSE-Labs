import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

T = 10      # 时隙数量
Pmax = 1    # 发射功率上限
lamda = 1.0 # 初始注水线为1

# 随机生成 a 的值
#a = np.random.rand(10)
# a = np.array([0.7962, 0.6912, 0.3453, 0.9468, 0.5202, 0.9538, 0.0736, 0.2070, 0.7750,0.9142])
a =np.array([0.77306234, 0.62994282, 0.77047448, 0.3520192, 0.03337611, 0.38844569, 0.13731907,0.48646228, 0.87022315, 0.73175709])
def objective_function(x):
    # 目标函数
    return T * 1 / (np.log(2) * x) - np.sum(1 / a)

def constraint_condition(x):
    # 约束条件 确保发射功率分配到每个时隙的总和不超过系统规定的最大发射功率
    return np.sum(np.maximum(1 / (np.log(2) * x) - 1 / a, 0)) - 1

# 优化求解
result = minimize(objective_function, lamda, constraints={'type': 'eq', 'fun': constraint_condition})

# 输出结果
lamda = result.x[0]
p = np.maximum(1 / (np.log(2) * lamda) - 1/a, 0)
# 计算信道容量
c = np.sum(np.log2(1 + p * a))

# 输出结果
print("总信道容量：", c)
print("注水线:", 1 / (np.log(2) * lamda))
# print(result)
# 以两列形式输出一组数据
combined_data = np.column_stack((a, p))
print("     ai          pi\n", combined_data)

# 绘制图形
fig, ax = plt.subplots()
ax.bar(range(1, T+1), 1/a, label='1/a', alpha=0.7 , width=0.7)
ax.axhline(y=1 / (np.log(2) * lamda), color='r', linestyle='--', label='Water filling line')
ax.set_xlabel('time')
ax.set_ylabel('1/a')
ax.legend()
plt.show()
