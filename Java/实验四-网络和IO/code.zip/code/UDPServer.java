import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashMap;

public class UDPServer {
    // 存储客户端的地址和端口信息
    private static HashMap<Integer, InetAddress> clientAddresses;
    private static HashMap<Integer, Integer> clientPorts;
    private static int clientId = 0;  // 用于为连接的客户端生成唯一ID

    public static void main(String[] args) throws Exception {
        clientAddresses = new HashMap<>();
        clientPorts = new HashMap<>();
        DatagramSocket serverSocket = new DatagramSocket(9876);  // 在端口9876上创建一个DatagramSocket以接收数据

        byte[] receiveData = new byte[1024];  // 接收数据的缓冲区

        System.out.println("Server is running...");  // 服务器启动提示

        while (true) {  // 服务器持续运行
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);  // 接收数据包
            InetAddress IPAddress = receivePacket.getAddress();  // 获取发送方的IP地址
            int port = receivePacket.getPort();  // 获取发送方的端口号

            String received = new String(receivePacket.getData(), 0, receivePacket.getLength());  // 从数据包中提取字符串
            System.out.println("Received: " + received + " from " + IPAddress + ":" + port);  // 打印接收到的信息

            // 检查是否为新客户端并将其添加到映射中
            if (!clientAddresses.containsValue(IPAddress) || !clientPorts.containsValue(port)) {
                clientId++;
                clientAddresses.put(clientId, IPAddress);
                clientPorts.put(clientId, port);
            }

            byte[] sendData = received.getBytes();  // 准备发送的数据
            // 将接收到的消息转发给除了发送者之外的所有客户端
            for (Integer id : clientAddresses.keySet()) {
                if (!clientAddresses.get(id).equals(IPAddress) || !clientPorts.get(id).equals(port)) {
                    InetAddress forwardIPAddress = clientAddresses.get(id);
                    int forwardPort = clientPorts.get(id);
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, forwardIPAddress, forwardPort);
                    serverSocket.send(sendPacket);  // 发送数据包
                    System.out.println("Sent to " + forwardIPAddress + ":" + forwardPort);  // 打印转发信息
                }
            }
        }
    }
}
