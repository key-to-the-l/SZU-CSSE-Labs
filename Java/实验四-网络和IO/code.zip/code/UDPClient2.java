import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient2 {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in); // 创建Scanner对象用于接收键盘输入
        DatagramSocket clientSocket = new DatagramSocket(); // 创建DatagramSocket无需指定端口因为是客户端
        InetAddress IPAddress = InetAddress.getByName("localhost"); // 获取服务器IP地址

        // 创建并启动一个线程用于接收服务器发来的数据
        Thread receiveThread = new Thread(() -> {
            try {
                byte[] receiveData = new byte[1024]; // 接收数据的缓冲区
                while (true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    clientSocket.receive(receivePacket); // 接收来自服务器的数据包
                    String received = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("Received from server: " + received); // 打印接收到的消息
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        receiveThread.start(); // 启动接收线程

        // 主线程用于发送数据到服务器
        while (true) {
            String sentence = scanner.nextLine(); // 读取用户输入
            byte[] sendData = sentence.getBytes(); // 将输入转换为字节数据
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
            clientSocket.send(sendPacket); // 发送数据包到服务器
        }
    }
}
