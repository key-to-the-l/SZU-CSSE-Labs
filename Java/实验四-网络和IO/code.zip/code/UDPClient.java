import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);  // 创建 Scanner 对象以读取键盘输入
        DatagramSocket clientSocket = new DatagramSocket();  // 创建 DatagramSocket 以发送和接收数据包
        InetAddress IPAddress = InetAddress.getByName("localhost");  // 获取服务器的IP地址，这里设置为本地

        // 创建并启动一个新线程用于接收数据
        Thread receiveThread = new Thread(() -> {
            try {
                while (true) {
                    byte[] receiveData = new byte[1024];  // 设置接收数据的缓冲区大小
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);  // 创建接收数据的包
                    clientSocket.receive(receivePacket);  // 从服务器接收数据包
                    String received = new String(receivePacket.getData(), 0, receivePacket.getLength());  // 将接收的数据转换为字符串
                    System.out.println("Received from server: " + received);  // 打印从服务器接收到的消息
                }
            } catch (Exception e) {
                e.printStackTrace();  // 打印异常信息
            }
        });
        receiveThread.start();  // 启动接收线程

        System.out.println("Enter messages to send:");  // 提示用户输入消息
        while (true) {  // 持续从键盘读取输入并发送到服务器
            String sentence = scanner.nextLine();  // 读取一行输入
            byte[] sendData = sentence.getBytes();  // 将输入字符串转换为字节数组
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);  // 创建发送数据的包
            clientSocket.send(sendPacket);  // 发送数据包到服务器
        }
    }
}
