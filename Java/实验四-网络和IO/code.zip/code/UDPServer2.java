import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ConcurrentHashMap;

public class UDPServer2 {
    // 使用线程安全的HashMap来存储客户端地址和端口
    private static ConcurrentHashMap<Integer, InetAddress> clientAddresses = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<Integer, Integer> clientPorts = new ConcurrentHashMap<>();
    private static int clientId = 0; // 用于分配给每个客户端的唯一ID

    public static void main(String[] args) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(9876); // 在端口9876上创建DatagramSocket
        System.out.println("Server is running...");

        // 创建并启动接收数据的线程
        Thread receiveThread = new Thread(() -> {
            try {
                byte[] receiveData = new byte[1024]; // 接收数据的缓冲区
                while (true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    serverSocket.receive(receivePacket); // 接收来自任何客户端的数据包
                    InetAddress IPAddress = receivePacket.getAddress(); // 获取发送方IP地址
                    int port = receivePacket.getPort(); // 获取发送方端口

                    String received = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("Received: " + received + " from " + IPAddress + ":" + port);

                    // 存储客户端地址和端口
                    clientAddresses.put(clientId, IPAddress);
                    clientPorts.put(clientId++, port);

                    // 将接收到的消息转发给所有其他客户端
                    sendToAll(received, IPAddress, port, serverSocket);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        receiveThread.start(); // 启动线程
    }

    // 该方法负责将消息发送给除了消息发送者之外的所有其他客户端
    private static void sendToAll(String received, InetAddress senderIP, int senderPort, DatagramSocket serverSocket) {
        byte[] sendData = received.getBytes();
        clientAddresses.forEach((id, ip) -> {
            int port = clientPorts.get(id);
            if (!ip.equals(senderIP) || port != senderPort) {
                try {
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, port);
                    serverSocket.send(sendPacket); // 发送数据包
                    System.out.println("Sent to " + ip + ":" + port);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
