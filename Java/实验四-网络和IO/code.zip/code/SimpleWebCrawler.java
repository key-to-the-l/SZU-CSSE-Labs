import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimpleWebCrawler {
    private HttpClient httpClient;
    private Set<String> visitedLinks = new HashSet<>();
    private final int MAX_PAGES = 10;

    public SimpleWebCrawler() {
        this.httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();
    }

    public void crawl(String startUrl) throws IOException, InterruptedException {
        if (visitedLinks.size() >= MAX_PAGES || visitedLinks.contains(startUrl)) {
            return; // 停止条件：已达到最大页面数或链接已访问过
        }

        visitedLinks.add(startUrl); // 记录已访问的链接
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(startUrl))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        savePageToFile(startUrl, response.body()); // 保存页面到本地文件
        findAndCrawlLinks(response.body()); // 解析网页内容中的超链接并递归访问
    }

    private void savePageToFile(String url, String content) {
        String fileName = "Page_" + visitedLinks.size() + "_" + url.hashCode() + ".html";
        File file = new File(fileName);
        try (OutputStream outputStream = new FileOutputStream(file)) {
            outputStream.write(content.getBytes()); // 将网页内容转为字节写入文件
            System.out.println("Saved: " + fileName);
        } catch (IOException e) {
            System.err.println("Failed to save " + fileName + ": " + e.getMessage());
        }
    }

    private void findAndCrawlLinks(String content) throws IOException, InterruptedException {
        Pattern pattern = Pattern.compile("<a\\s+href=\"(http[s]?://[^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(content);

        while (matcher.find() && visitedLinks.size() < MAX_PAGES) {
            String foundUrl = matcher.group(1); // 提取超链接
            crawl(foundUrl); // 递归抓取
        }
    }

    public static void main(String[] args) {
        SimpleWebCrawler crawler = new SimpleWebCrawler();
        try {
            crawler.crawl("https://csse.szu.edu.cn/pages/news/index"); // 起始网址
        } catch (IOException | InterruptedException e) {
            System.err.println("Error during crawling: " + e.getMessage());
        }
    }
}

