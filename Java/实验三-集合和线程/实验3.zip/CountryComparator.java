import java.util.Comparator;
import java.util.TreeMap;
class Country {
    private final String name;
    private final long gdp2020;
    private final long covid19;

    public Country(String name, long gdp2020, long covid19) {
        this.name = name;
        this.gdp2020 = gdp2020;
        this.covid19 = covid19;
    }

    public String getName() {
        return name;
    }

    public long getGdp2020() {
        return gdp2020;
    }

    public long getCovid19() {
        return covid19;
    }
}


class CovidComparator implements Comparator<Country> {
    @Override
    public int compare(Country c1, Country c2) {
        return Long.compare(c1.getCovid19(), c2.getCovid19());
    }
}


public class CountryComparator {
    public static void main(String[] args) {
        TreeMap<Country, String> countryMap = new TreeMap<>(new CovidComparator());

        Country usa = new Country("美国", 20932750, 44918565);
        Country china = new Country("中华人民共和国", 14722837, 124924);
        Country japan = new Country("日本", 5048688, 1706675);
        Country germany = new Country("德国", 3803014, 4284354);
        Country uk = new Country("英国", 2710970, 8006660);
        Country india = new Country("印度", 2708770, 33893002);
        Country france = new Country("法国", 2598907, 7038701);
        Country italy = new Country("意大利", 1884935, 4689341);
        Country canada = new Country("加拿大", 1643408, 1647142);
        Country southKorea = new Country("韩国", 1630871, 323379);

        countryMap.put(usa, "");
        countryMap.put(china, "");
        countryMap.put(japan, "");
        countryMap.put(germany, "");
        countryMap.put(uk, "");
        countryMap.put(india, "");
        countryMap.put(france, "");
        countryMap.put(italy, "");
        countryMap.put(canada, "");
        countryMap.put(southKorea, "");

        for (Country country : countryMap.keySet()) {
            System.out.println(country.getName() + " " + country.getGdp2020() + " " + country.getCovid19());
        }
    }
}