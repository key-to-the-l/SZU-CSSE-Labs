import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class CollectionsOperation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入一组数字，以逗号分隔:");
        String input = scanner.nextLine();
        String[] numbersStr = input.split(",");
        List<Integer> numberList = new ArrayList<>();
        for (String numStr : numbersStr) {
            numberList.add(Integer.parseInt(numStr.trim()));
        }

        // 对列表进行排序
        List<Integer> sortedList = new ArrayList<>(numberList);
        Collections.sort(sortedList);
        System.out.println("排序后的列表: " + sortedList);

        // 查找最大值和最小值
        int max = Collections.max(sortedList);
        int min = Collections.min(sortedList);
        System.out.println("最大值: " + max);
        System.out.println("最小值: " + min);

        // 将列表中的所有元素翻倍
        List<Integer> doubledList = new ArrayList<>();
        for (Integer num : sortedList) {
            doubledList.add(num * 2);
        }
        System.out.println("所有元素翻倍后的列表: " + doubledList);

        // 移除重复元素
        Set<Integer> set = new HashSet<>(sortedList);
        List<Integer> uniqueList = new ArrayList<>(set);
        System.out.println("移除重复元素后的列表: " + uniqueList);

        scanner.close();
    }
}