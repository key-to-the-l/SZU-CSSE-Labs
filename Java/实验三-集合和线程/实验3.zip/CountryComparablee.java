import java.util.TreeMap;
class CountryComparable implements Comparable<CountryComparable> {
    private String name;
    private long gdp2020;
    private long covid19;

    public CountryComparable(String name, long gdp2020, long covid19) {
        this.name = name;
        this.gdp2020 = gdp2020;
        this.covid19 = covid19;
    }

    public String getName() {
        return name;
    }

    public long getGdp2020() {
        return gdp2020;
    }

    public long getCovid19() {
        return covid19;
    }

    @Override
    public int compareTo(CountryComparable other) {
        return Long.compare(this.covid19, other.covid19);
    }
}


public class CountryComparablee {
    public static void main(String[] args) {
        TreeMap<CountryComparable, String> countryMap = new TreeMap<>();

        CountryComparable usa = new CountryComparable("美国", 20932750, 44918565);
        CountryComparable china = new CountryComparable("中华人民共和国", 14722837, 124924);
        CountryComparable japan = new CountryComparable("日本", 5048688, 1706675);
        CountryComparable germany = new CountryComparable("德国", 3803014, 4284354);
        CountryComparable uk = new CountryComparable("英国", 2710970, 8006660);
        CountryComparable india = new CountryComparable("印度", 2708770, 33893002);
        CountryComparable france = new CountryComparable("法国", 2598907, 7038701);
        CountryComparable italy = new CountryComparable("意大利", 1884935, 4689341);
        CountryComparable canada = new CountryComparable("加拿大", 1643408, 1647142);
        CountryComparable southKorea = new CountryComparable("韩国", 1630871, 323379);

        countryMap.put(usa, "");
        countryMap.put(china, "");
        countryMap.put(japan, "");
        countryMap.put(germany, "");
        countryMap.put(uk, "");
        countryMap.put(india, "");
        countryMap.put(france, "");
        countryMap.put(italy, "");
        countryMap.put(canada, "");
        countryMap.put(southKorea, "");

        for (CountryComparable country : countryMap.keySet()) {
            System.out.println(country.getName() + " " + country.getGdp2020() + " " + country.getCovid19());
        }
    }
}