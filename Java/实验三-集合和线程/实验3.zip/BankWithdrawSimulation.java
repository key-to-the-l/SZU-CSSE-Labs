class BankAccount {
    private int balance = 1000;

    public synchronized void withdraw(int amount) {
        if (balance >= amount) {
            System.out.println(Thread.currentThread().getName() + " is withdrawing " + amount);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " has withdrawn " + amount + ", remaining balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " insufficient funds");
        }
    }
}

class WithdrawRunnable implements Runnable {
    private BankAccount account;
    private int amount;

    public WithdrawRunnable(BankAccount account, int amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.withdraw(amount);
    }
}

public class BankWithdrawSimulation {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        Thread thread1 = new Thread(new WithdrawRunnable(account, 300));
        Thread thread2 = new Thread(new WithdrawRunnable(account, 400));
        Thread thread3 = new Thread(new WithdrawRunnable(account, 300));

        thread1.start();
        thread2.start();
        thread3.start();
    }
}